

# Server

Website server (Website Controller): 

https://v2d27.github.io/IoT/ 


MQTT server (MQTT Broker) - hosted message for devices connections: 

https://www.cloudmqtt.com/

# System Block Diagran

![wallpaper](https://v2d27.github.io/IoT/image/system-diagram.png)
=======

# Preview

###Homepage page

![wallpaper](https://github.com/Hercules2404/IoT/blob/master/Preview/homepage.JPG)
=======

###Connect page

![wallpaper](https://github.com/Hercules2404/IoT/blob/master/Preview/connect.JPG)
=======

###Control Device

![wallpaper](https://github.com/Hercules2404/IoT/blob/master/Preview/control.JPG)
=======

# Date publish

Feburary, 2018



# Contact with us

Gmail: ducduc08@gmail.com



# License

Please do not edit this source and do not use as economical purpose. Thank you!

